import 'dart:convert';

import 'package:bloc/bloc.dart';
import 'package:equatable/equatable.dart';
import 'package:flutter/cupertino.dart';

import '../../UI/intropage/auth_repository.dart';
import '../../model/login/LoginPojo.dart';
import '../../untils/local/SharedPrefs.dart';
import '../../untils/validation.dart';
import '../../untils/widget/commonUtility.dart';

part 'login_event.dart';

part 'login_state.dart';

class LoginBloc extends Bloc<LoginEvent, LoginState> {
  final TextEditingController emailController = TextEditingController();
  final TextEditingController passwordController = TextEditingController();

  LoginBloc() : super(LoginInitial()) {
    on<LoginStart>(loginAction);
  }

  Future<void> loginAction(LoginStart event, Emitter<LoginState> emit) async {
    String email = emailController.text;
    String password = passwordController.text;
    String? emailValidationMessage = Validation.validateEmail(email);
    String? passwordValidationMessage = Validation.validatePassword(password);

    if (emailValidationMessage != null) {
      emit(LoginError(emailValidationMessage));
      return;
    }

    if (passwordValidationMessage != null) {
      emit(LoginError(passwordValidationMessage));
      return;
    }

    emit(LoginLoading());
    try {
      dynamic loginData =
          await AuthRepository.login(event.email, event.password);
      var data = json.decode(loginData.body);
      if (data['code'] == 200) {
        SharedPrefs.setString("bemail", event.email ?? "");
        SharedPrefs.setString("bpassword", event.password ?? "");
        var loadedData = LoginPojo.fromJson(data);
        emit(LoginSuccess(loadedData));
      }
      {
        emit(LoginError(data['message']));
      }
    } catch (e) {
      emit(LoginError(e.toString()));
    }
  }
}
